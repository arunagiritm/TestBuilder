define(['jQuery', 'angular', 'angular-mock'], function($) {

//Declare all global variables here
var addressFactory, appConfig,
    CommonDataService;

// Read mock data from external file uncomment this to read mock data from json file

// $.get('base/test/unit/claims/dental/JSON/dentalBasicClaim.json',function(data){
// 	var mockData=JSON.parse(data.toString());
// });

//Any other mock objects/ functions that is required can be intialized here
// require("generalFunctions");

//Main describe here
describe('addressFactory', function() {

    //beforeEach function.  create and intialize module, controllers and services here
    beforeEach(function() {
        spyOn(angular, 'element').and.callFake(mockData.angularFaked);
        module(he);
        inject(function(_addressFactory_, _appConfig_, _CommonDataService_) {
            appConfig = _appConfig_;
            CommonDataService = _CommonDataService_;
            addressFactory = _addressFactory_;
        });


    });
});

afterEach(function() {

});

//create additional describes if needed

//create your it and expect statements here
it('should instantiate addressFactory', function() {
    expect(addressFactory).toBeDefined();
});

it('should call addressdetail', function() {
    //Invoke the method call
    addressFactory.addressdetail();
    //modify your expect statement to match your logic
    expect(addressFactory.addressdetail).toBeTrue()
});

it('should call thataddressdetail.setOrganisation ', function() {
    //Invoke the method call
    addressFactory.setOrganisation(mockData.organisation);
    //modify your expect statement to match your logic
    expect(addressFactory.setOrganisation).toBeTrue()
});

it('should call thataddressdetail.setPhone ', function() {
    //Invoke the method call
    addressFactory.setPhone(mockData.phone);
    //modify your expect statement to match your logic
    expect(addressFactory.setPhone).toBeTrue()
});

it('should call thataddressdetail.setExt ', function() {
    //Invoke the method call
    addressFactory.setExt(mockData.ext);
    //modify your expect statement to match your logic
    expect(addressFactory.setExt).toBeTrue()
});

it('should call thataddressdetail.setAttention ', function() {
    //Invoke the method call
    addressFactory.setAttention(mockData.attention);
    //modify your expect statement to match your logic
    expect(addressFactory.setAttention).toBeTrue()
});

it('should call thataddressdetail.setContactFirstname ', function() {
    //Invoke the method call
    addressFactory.setContactFirstname(mockData.contactFirstname);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactFirstname).toBeTrue()
});

it('should call thataddressdetail.setContactLastname ', function() {
    //Invoke the method call
    addressFactory.setContactLastname(mockData.contactFirstname);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactLastname).toBeTrue()
});

it('should call thataddressdetail.setContactName ', function() {
    //Invoke the method call
    addressFactory.setContactName(mockData.contactname);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactName).toBeTrue()
});

it('should call thataddressdetail.setContactPhone ', function() {
    //Invoke the method call
    addressFactory.setContactPhone(mockData.contactphone);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactPhone).toBeTrue()
});

it('should call thataddressdetail.setContactExt ', function() {
    //Invoke the method call
    addressFactory.setContactExt(mockData.contactext);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactExt).toBeTrue()
});

it('should call thataddressdetail.setContactFax ', function() {
    //Invoke the method call
    addressFactory.setContactFax(mockData.contactfax);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactFax).toBeTrue()
});

it('should call thataddressdetail.setContactEmail ', function() {
    //Invoke the method call
    addressFactory.setContactEmail(mockData.contactemail);
    //modify your expect statement to match your logic
    expect(addressFactory.setContactEmail).toBeTrue()
});

it('should call thataddressdetail.setAddressLine1 ', function() {
    //Invoke the method call
    addressFactory.setAddressLine1(mockData.addressLine1);
    //modify your expect statement to match your logic
    expect(addressFactory.setAddressLine1).toBeTrue()
});

it('should call thataddressdetail.setAddressLine2 ', function() {
    //Invoke the method call
    addressFactory.setAddressLine2(mockData.addressLine2);
    //modify your expect statement to match your logic
    expect(addressFactory.setAddressLine2).toBeTrue()
});

it('should call thataddressdetail.setCity ', function() {
    //Invoke the method call
    addressFactory.setCity(mockData.city);
    //modify your expect statement to match your logic
    expect(addressFactory.setCity).toBeTrue()
});

it('should call thataddressdetail.setState ', function() {
    //Invoke the method call
    addressFactory.setState(mockData.state);
    //modify your expect statement to match your logic
    expect(addressFactory.setState).toBeTrue()
});

it('should call thataddressdetail.setZip ', function() {
    //Invoke the method call
    addressFactory.setZip(mockData.zip);
    //modify your expect statement to match your logic
    expect(addressFactory.setZip).toBeTrue()
});

it('should call thataddressdetail.setPlus4 ', function() {
    //Invoke the method call
    addressFactory.setPlus4(mockData.plus4);
    //modify your expect statement to match your logic
    expect(addressFactory.setPlus4).toBeTrue()
});

it('should call thataddressdetail.setSubDivisionCode ', function() {
    //Invoke the method call
    addressFactory.setSubDivisionCode(mockData.subdivisioncode);
    //modify your expect statement to match your logic
    expect(addressFactory.setSubDivisionCode).toBeTrue()
});

it('should call thataddressdetail.setCountry ', function() {
    //Invoke the method call
    addressFactory.setCountry(mockData.country);
    //modify your expect statement to match your logic
    expect(addressFactory.setCountry).toBeTrue()
});

it('should call thataddressdetail.setFirstname ', function() {
    //Invoke the method call
    addressFactory.setFirstname(mockData.firstname);
    //modify your expect statement to match your logic
    expect(addressFactory.setFirstname).toBeTrue()
});

it('should call thataddressdetail.setLastname ', function() {
    //Invoke the method call
    addressFactory.setLastname(mockData.lastname);
    //modify your expect statement to match your logic
    expect(addressFactory.setLastname).toBeTrue()
});

it('should call thataddressdetail.setMiddlename ', function() {
    //Invoke the method call
    addressFactory.setMiddlename(mockData.middlename);
    //modify your expect statement to match your logic
    expect(addressFactory.setMiddlename).toBeTrue()
});

it('should call thataddressdetail.setPrefix ', function() {
    //Invoke the method call
    addressFactory.setPrefix(mockData.prefix);
    //modify your expect statement to match your logic
    expect(addressFactory.setPrefix).toBeTrue()
});

it('should call thataddressdetail.setSuffix ', function() {
    //Invoke the method call
    addressFactory.setSuffix(mockData.suffix);
    //modify your expect statement to match your logic
    expect(addressFactory.setSuffix).toBeTrue()
});

it('should call thataddressdetail.setMi ', function() {
    //Invoke the method call
    addressFactory.setMi(mockData.mi);
    //modify your expect statement to match your logic
    expect(addressFactory.setMi).toBeTrue()
});

it('should call thataddressdetail.setOrgNameOrLastName ', function() {
    //Invoke the method call
    addressFactory.setOrgNameOrLastName(mockData.orgNameOrLastName);
    //modify your expect statement to match your logic
    expect(addressFactory.setOrgNameOrLastName).toBeTrue()
});

it('should call thataddressdetail.getOrganisation ', function() {
    //Invoke the method call
    addressFactory.getOrganisation();
    //modify your expect statement to match your logic
    expect(addressFactory.getOrganisation).toBeTrue()
});

it('should call thataddressdetail.getPhone ', function() {
    //Invoke the method call
    addressFactory.getPhone();
    //modify your expect statement to match your logic
    expect(addressFactory.getPhone).toBeTrue()
});

it('should call thataddressdetail.getExt ', function() {
    //Invoke the method call
    addressFactory.getExt();
    //modify your expect statement to match your logic
    expect(addressFactory.getExt).toBeTrue()
});

it('should call thataddressdetail.getAttention ', function() {
    //Invoke the method call
    addressFactory.getAttention();
    //modify your expect statement to match your logic
    expect(addressFactory.getAttention).toBeTrue()
});

it('should call thataddressdetail.getContactFirstname ', function() {
    //Invoke the method call
    addressFactory.getContactFirstname();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactFirstname).toBeTrue()
});

it('should call thataddressdetail.getContactLastname ', function() {
    //Invoke the method call
    addressFactory.getContactLastname();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactLastname).toBeTrue()
});

it('should call thataddressdetail.getContactName ', function() {
    //Invoke the method call
    addressFactory.getContactName();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactName).toBeTrue()
});

it('should call thataddressdetail.getContactPhone ', function() {
    //Invoke the method call
    addressFactory.getContactPhone();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactPhone).toBeTrue()
});

it('should call thataddressdetail.getContactExt ', function() {
    //Invoke the method call
    addressFactory.getContactExt();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactExt).toBeTrue()
});

it('should call thataddressdetail.getContactFax ', function() {
    //Invoke the method call
    addressFactory.getContactFax();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactFax).toBeTrue()
});

it('should call thataddressdetail.getContactEmail ', function() {
    //Invoke the method call
    addressFactory.getContactEmail();
    //modify your expect statement to match your logic
    expect(addressFactory.getContactEmail).toBeTrue()
});

it('should call thataddressdetail.getAddressLine1 ', function() {
    //Invoke the method call
    addressFactory.getAddressLine1();
    //modify your expect statement to match your logic
    expect(addressFactory.getAddressLine1).toBeTrue()
});

it('should call thataddressdetail.getAddressLine2 ', function() {
    //Invoke the method call
    addressFactory.getAddressLine2();
    //modify your expect statement to match your logic
    expect(addressFactory.getAddressLine2).toBeTrue()
});

it('should call thataddressdetail.getCity ', function() {
    //Invoke the method call
    addressFactory.getCity();
    //modify your expect statement to match your logic
    expect(addressFactory.getCity).toBeTrue()
});

it('should call thataddressdetail.getState ', function() {
    //Invoke the method call
    addressFactory.getState();
    //modify your expect statement to match your logic
    expect(addressFactory.getState).toBeTrue()
});

it('should call thataddressdetail.getZip ', function() {
    //Invoke the method call
    addressFactory.getZip();
    //modify your expect statement to match your logic
    expect(addressFactory.getZip).toBeTrue()
});

it('should call thataddressdetail.getPlus4 ', function() {
    //Invoke the method call
    addressFactory.getPlus4();
    //modify your expect statement to match your logic
    expect(addressFactory.getPlus4).toBeTrue()
});

it('should call thataddressdetail.getSubDivisionCode ', function() {
    //Invoke the method call
    addressFactory.getSubDivisionCode();
    //modify your expect statement to match your logic
    expect(addressFactory.getSubDivisionCode).toBeTrue()
});

it('should call thataddressdetail.getCountry ', function() {
    //Invoke the method call
    addressFactory.getCountry();
    //modify your expect statement to match your logic
    expect(addressFactory.getCountry).toBeTrue()
});

it('should call thataddressdetail.getFirstname ', function() {
    //Invoke the method call
    addressFactory.getFirstname();
    //modify your expect statement to match your logic
    expect(addressFactory.getFirstname).toBeTrue()
});

it('should call thataddressdetail.getLastname ', function() {
    //Invoke the method call
    addressFactory.getLastname();
    //modify your expect statement to match your logic
    expect(addressFactory.getLastname).toBeTrue()
});

it('should call thataddressdetail.getMiddlename ', function() {
    //Invoke the method call
    addressFactory.getMiddlename();
    //modify your expect statement to match your logic
    expect(addressFactory.getMiddlename).toBeTrue()
});

it('should call thataddressdetail.getPrefix ', function() {
    //Invoke the method call
    addressFactory.getPrefix();
    //modify your expect statement to match your logic
    expect(addressFactory.getPrefix).toBeTrue()
});

it('should call thataddressdetail.getSuffix ', function() {
    //Invoke the method call
    addressFactory.getSuffix();
    //modify your expect statement to match your logic
    expect(addressFactory.getSuffix).toBeTrue()
});

it('should call thataddressdetail.getMi ', function() {
    //Invoke the method call
    addressFactory.getMi();
    //modify your expect statement to match your logic
    expect(addressFactory.getMi).toBeTrue()
});

it('should call thataddressdetail.getOrgNameOrLastName ', function() {
    //Invoke the method call
    addressFactory.getOrgNameOrLastName();
    //modify your expect statement to match your logic
    expect(addressFactory.getOrgNameOrLastName).toBeTrue()
});

it('should call thataddressdetail.validateZip ', function() {
    //Invoke the method call
    addressFactory.validateZip(mockData.suffix, mockData.errorList);
    //modify your expect statement to match your logic
    expect(addressFactory.validateZip).toBeTrue()
});

it('should call thataddressdetail.validateCountry ', function() {
    //Invoke the method call
    addressFactory.validateCountry(mockData.suffix, mockData.errorList);
    //modify your expect statement to match your logic
    expect(addressFactory.validateCountry).toBeTrue()
});

it('should call thataddressdetail.validateAddress ', function() {
    //Invoke the method call
    addressFactory.validateAddress(mockData.suffix, mockData.errorList);
    //modify your expect statement to match your logic
    expect(addressFactory.validateAddress).toBeTrue()
});

it('should call thataddressdetail.pushMessage ', function() {
    //Invoke the method call
    addressFactory.pushMessage(mockData.msg, mockData.errorList);
    //modify your expect statement to match your logic
    expect(addressFactory.pushMessage).toBeTrue()
});

it('should call thataddressdetail.validateContact ', function() {
    //Invoke the method call
    addressFactory.validateContact(mockData.suffix, mockData.errorList);
    //modify your expect statement to match your logic
    expect(addressFactory.validateContact).toBeTrue()
});




});


});