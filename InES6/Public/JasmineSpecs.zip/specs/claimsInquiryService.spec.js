define(['jQuery', 'angular', 'angular-mock'], function($) {

//Declare all global variables here
var claimsInquiryService, scope,
    $httpBackend,
    claimsRestClientFactory,
    $q,
    appConfig,
    logger;

// Read mock data from external file uncomment this to read mock data from json file

// $.get('base/test/unit/claims/dental/JSON/dentalBasicClaim.json',function(data){
// 	var mockData=JSON.parse(data.toString());
// });

//Any other mock objects/ functions that is required can be intialized here
// require("generalFunctions");

//Main describe here
describe('claimsInquiryService', function() {

    //beforeEach function.  create and intialize module, controllers and services here
    beforeEach(function() {
        spyOn(angular, 'element').and.callFake(mockData.angularFaked);
        module(he);
        inject(function($rootScope, _$httpBackend_, _claimsRestClientFactory_, _$q_, _appConfig_, _logger_) {
            scope = $rootScope.$new();
            $httpBackend = _$httpBackend_;
            claimsRestClientFactory = _claimsRestClientFactory_;
            $q = _$q_;
            appConfig = _appConfig_;
            logger = _logger_;
        });

        $httpBackend.whenGET(/.*(.json|.html)/gi).respond(200, {})
    });
});

afterEach(function() {
    $httpBackend.verifyNoOutstandingExpectation();
    $httpBackend.verifyNoOutstandingRequest();

});

//create additional describes if needed

//create your it and expect statements here
it('should instantiate claimsInquiryService', function() {
    expect(claimsInquiryService).toBeDefined();
});


describe('Call searchClaimInquiry method', function() {

    it('Success callback && pass the null data', function() {

        url = mockData.searchClaimInquiry.url;
        sendSuccessRequest(url, mockData.searchClaimInquiry.inValidData);
        var promise = searchClaimInquiry(mockData.searchClaimInquiry.inValidData);
        promise.then(function(res) {
            expect(res.route).toEqual(mockData.searchClaimInquiry.route);
        });

    });

    it('Success callback for searchClaimInquiry && pass the required data', function() {

        url = mockData.searchClaimInquiry.url;
        sendSuccessRequest(url, mockData.searchClaimInquiry.ValidData);
        var promise = searchClaimInquiry(mockData.searchClaimInquiry.ValidData);
        promise.then(function(res) {
            expect(res.route).toEqual(mockData.searchClaimInquiry.route);
            expect(res.providerID).toEqual(mockData.providerID);
        });

    });

    it('Failure callback for searchClaimInquiry', function() {

        url = mockData.searchClaimInquiry.url;
        sendFailureRequest(url, mockData.searchClaimInquiry.ValidData);
        var promise = searchClaimInquiry(mockData.searchClaimInquiry.ValidData);

        promise.then(function(res) {

        }, function(e) {
            expect(e.status).toBe(0);
        });

    });
});



describe('Call getClaimDetails method', function() {

    it('Success callback && pass the null data', function() {

        url = mockData.getClaimDetails.url;
        sendSuccessRequest(url, mockData.getClaimDetails.inValidData);
        var promise = getClaimDetails(mockData.getClaimDetails.inValidData);
        promise.then(function(res) {
            expect(res.route).toEqual(mockData.getClaimDetails.route);
        });

    });

    it('Success callback for getClaimDetails && pass the required data', function() {

        url = mockData.getClaimDetails.url;
        sendSuccessRequest(url, mockData.getClaimDetails.ValidData);
        var promise = getClaimDetails(mockData.getClaimDetails.ValidData);
        promise.then(function(res) {
            expect(res.route).toEqual(mockData.getClaimDetails.route);
            expect(res.providerID).toEqual(mockData.providerID);
        });

    });

    it('Failure callback for getClaimDetails', function() {

        url = mockData.getClaimDetails.url;
        sendFailureRequest(url, mockData.getClaimDetails.ValidData);
        var promise = getClaimDetails(mockData.getClaimDetails.ValidData);

        promise.then(function(res) {

        }, function(e) {
            expect(e.status).toBe(0);
        });

    });
});





});


});