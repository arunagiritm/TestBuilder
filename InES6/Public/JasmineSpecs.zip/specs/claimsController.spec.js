define(['jQuery', 'angular', 'angular-mock'], function($) {

    //Declare all global variables here
    var claimsController, scope,
        $scope,
        $state,
        $modal,
        otherClaimInfoDataService,
        CommonDataService,
        notificationSrvc,
        usSpinnerService,
        mmisUIService,
        listenerFactory,
        appConfig,
        appUtil,
        $injector,
        claimsService,
        accordianFactory,
        commonCacheFactory,
        errorFactory,
        saveDentalClaim,
        basicLineGrid,
        otherCoOrdinationOfBenefitsGroup,
        dentalServiceInfoFactory,
        otherServiceInfoAccordion;

    // Read mock data from external file uncomment this to read mock data from json file

    // $.get('base/test/unit/claims/dental/JSON/dentalBasicClaim.json',function(data){
    // 	var mockData=JSON.parse(data.toString());
    // });

    //Any other mock objects/ functions that is required can be intialized here
    // require("generalFunctions");

    //Main describe here
    describe('claimsController', function() {

        //beforeEach function.  create and intialize module, controllers and services here
        beforeEach(function() {
            spyOn(angular, 'element').and.callFake(mockData.angularFaked);
            module(he);
            inject(function($rootScope, $controller, _$state_, _$modal_, _otherClaimInfoDataService_, _CommonDataService_, _notificationSrvc_, _usSpinnerService_, _mmisUIService_, _listenerFactory_, _appConfig_, _appUtil_, _$injector_, _claimsService_, _accordianFactory_, _commonCacheFactory_, _errorFactory_, _saveDentalClaim_, _basicLineGrid_, _otherCoOrdinationOfBenefitsGroup_, _dentalServiceInfoFactory_, _otherServiceInfoAccordion_) {
                scope = $rootScope.$new();
                $state = _$state_;
                $modal = _$modal_;
                otherClaimInfoDataService = _otherClaimInfoDataService_;
                CommonDataService = _CommonDataService_;
                notificationSrvc = _notificationSrvc_;
                usSpinnerService = _usSpinnerService_;
                mmisUIService = _mmisUIService_;
                listenerFactory = _listenerFactory_;
                appConfig = _appConfig_;
                appUtil = _appUtil_;
                $injector = _$injector_;
                claimsService = _claimsService_;
                accordianFactory = _accordianFactory_;
                commonCacheFactory = _commonCacheFactory_;
                errorFactory = _errorFactory_;
                saveDentalClaim = _saveDentalClaim_;
                basicLineGrid = _basicLineGrid_;
                otherCoOrdinationOfBenefitsGroup = _otherCoOrdinationOfBenefitsGroup_;
                dentalServiceInfoFactory = _dentalServiceInfoFactory_;
                otherServiceInfoAccordion = _otherServiceInfoAccordion_;
                claimsController = $controller('claimsController', {
                    $scope: scope
                });


            });
        });

        afterEach(function() {

        });

        //create additional describes if needed

        //create your it and expect statements here
        it('should instantiate claimsController', function() {
            expect(claimsController).toBeDefined();
            expect(scope).toBeDefined();
        });

        it('should call scope.getClaimInfo ', function() {
            //Invoke the method call
            scope.getClaimInfo();
            //modify your expect statement to match your logic
            expect(scope.getClaimInfo).toBeTrue()
        });

        it('should call scope.mapSrvtoUI ', function() {
            //Invoke the method call
            scope.mapSrvtoUI(mockData.response);
            //modify your expect statement to match your logic
            expect(scope.mapSrvtoUI).toBeTrue()
        });

        it('should call scope.init ', function() {
            //Invoke the method call
            scope.init();
            //modify your expect statement to match your logic
            expect(scope.init).toBeTrue()
        });

        it('should call scope.setTab ', function() {
            //Invoke the method call
            scope.setTab(mockData.tabId);
            //modify your expect statement to match your logic
            expect(scope.setTab).toBeTrue()
        });

        it('should call scope.isSet ', function() {
            //Invoke the method call
            scope.isSet(mockData.tabId);
            //modify your expect statement to match your logic
            expect(scope.isSet).toBeTrue()
        });

        it('should call scope.removeBorder ', function() {
            //Invoke the method call
            scope.removeBorder(mockData.id);
            //modify your expect statement to match your logic
            expect(scope.removeBorder).toBeTrue()
        });

        it('should call scope.goToNewClaim ', function() {
            //Invoke the method call
            scope.goToNewClaim();
            //modify your expect statement to match your logic
            expect(scope.goToNewClaim).toBeTrue()
        });

        it('should call scope.returnToBasicClaim ', function() {
            //Invoke the method call
            scope.returnToBasicClaim();
            //modify your expect statement to match your logic
            expect(scope.returnToBasicClaim).toBeTrue()
        });

        it('should call scope.cancelOSiClaim ', function() {
            //Invoke the method call
            scope.cancelOSiClaim();
            //modify your expect statement to match your logic
            expect(scope.cancelOSiClaim).toBeTrue()
        });

        it('should call scope.saveAndReturnToBSLI ', function() {
            //Invoke the method call
            scope.saveAndReturnToBSLI(mockData.serviceEditableIdx);
            //modify your expect statement to match your logic
            expect(scope.saveAndReturnToBSLI).toBeTrue()
        });

        it('should call scope.goToBasicClaim ', function() {
            //Invoke the method call
            scope.goToBasicClaim();
            //modify your expect statement to match your logic
            expect(scope.goToBasicClaim).toBeTrue()
        });

        it('should call scope.goToOtherClaim ', function() {
            //Invoke the method call
            scope.goToOtherClaim();
            //modify your expect statement to match your logic
            expect(scope.goToOtherClaim).toBeTrue()
        });

        it('should call scope.goToCOB ', function() {
            //Invoke the method call
            scope.goToCOB();
            //modify your expect statement to match your logic
            expect(scope.goToCOB).toBeTrue()
        });

        it('should call scope.saveClaim ', function() {
            //Invoke the method call
            scope.saveClaim();
            //modify your expect statement to match your logic
            expect(scope.saveClaim).toBeTrue()
        });

        it('should call scope.submitClaim ', function() {
            //Invoke the method call
            scope.submitClaim();
            //modify your expect statement to match your logic
            expect(scope.submitClaim).toBeTrue()
        });

        it('should call d_dentalattachmenttype', function() {
            //Invoke the method call
            claimsController.d_dentalattachmenttype(mockData.CommonDataService);
            //modify your expect statement to match your logic
            expect(claimsController.d_dentalattachmenttype).toBeTrue()
        });

        it('should call d_attachmenttype', function() {
            //Invoke the method call
            claimsController.d_attachmenttype(mockData.CommonDataService);
            //modify your expect statement to match your logic
            expect(claimsController.d_attachmenttype).toBeTrue()
        });

        it('should call d_claimsdeliverymethod', function() {
            //Invoke the method call
            claimsController.d_claimsdeliverymethod(mockData.CommonDataService);
            //modify your expect statement to match your logic
            expect(claimsController.d_claimsdeliverymethod).toBeTrue()
        });

        it('should call d_attachmentlevel', function() {
            //Invoke the method call
            claimsController.d_attachmentlevel(mockData.CommonDataService);
            //modify your expect statement to match your logic
            expect(claimsController.d_attachmentlevel).toBeTrue()
        });

        it('should call scope.validateSubmitlClaim ', function() {
            //Invoke the method call
            scope.validateSubmitlClaim();
            //modify your expect statement to match your logic
            expect(scope.validateSubmitlClaim).toBeTrue()
        });

        it('should call scope.validateSaveClaim ', function() {
            //Invoke the method call
            scope.validateSaveClaim();
            //modify your expect statement to match your logic
            expect(scope.validateSaveClaim).toBeTrue()
        });

        it('should call scope.validateSaveOtherService ', function() {
            //Invoke the method call
            scope.validateSaveOtherService();
            //modify your expect statement to match your logic
            expect(scope.validateSaveOtherService).toBeTrue()
        });

        it('should call scope.remove ', function() {
            //Invoke the method call
            scope.remove();
            //modify your expect statement to match your logic
            expect(scope.remove).toBeTrue()
        });

        it('should call message', function() {
            //Invoke the method call
            claimsController.message();
            //modify your expect statement to match your logic
            expect(claimsController.message).toBeTrue()
        });

        it('should call scope.cancelSearchClaim ', function() {
            //Invoke the method call
            scope.cancelSearchClaim(mockData.reset);
            //modify your expect statement to match your logic
            expect(scope.cancelSearchClaim).toBeTrue()
        });

        it('should call scope.viewSubmittedAttachment ', function() {
            //Invoke the method call
            scope.viewSubmittedAttachment();
            //modify your expect statement to match your logic
            expect(scope.viewSubmittedAttachment).toBeTrue()
        });

        it('should call scope.cancelPopup ', function() {
            //Invoke the method call
            scope.cancelPopup();
            //modify your expect statement to match your logic
            expect(scope.cancelPopup).toBeTrue()
        });

        it('should call scope.collapseAccordian ', function() {
            //Invoke the method call
            scope.collapseAccordian(mockData.accElement, mockData.accId);
            //modify your expect statement to match your logic
            expect(scope.collapseAccordian).toBeTrue()
        });

        it('should call scope.resetClaim ', function() {
            //Invoke the method call
            scope.resetClaim(mockData.reset);
            //modify your expect statement to match your logic
            expect(scope.resetClaim).toBeTrue()
        });

        it('should call scope.resetOtherServiceTab ', function() {
            //Invoke the method call
            scope.resetOtherServiceTab();
            //modify your expect statement to match your logic
            expect(scope.resetOtherServiceTab).toBeTrue()
        });

        it('should call scope.validateTCN ', function() {
            //Invoke the method call
            scope.validateTCN();
            //modify your expect statement to match your logic
            expect(scope.validateTCN).toBeTrue()
        });

        it('should call scope.hoverOut ', function() {
            //Invoke the method call
            scope.hoverOut();
            //modify your expect statement to match your logic
            expect(scope.hoverOut).toBeTrue()
        });

        it('should call scope.clearOtherServiceCSS ', function() {
            //Invoke the method call
            scope.clearOtherServiceCSS();
            //modify your expect statement to match your logic
            expect(scope.clearOtherServiceCSS).toBeTrue()
        });

        it('should call scope.errorAccordionClose ', function() {
            //Invoke the method call
            scope.errorAccordionClose(mockData.openid, mockData.closeid);
            //modify your expect statement to match your logic
            expect(scope.errorAccordionClose).toBeTrue()
        });

        it('should call scope.validateBlank ', function() {
            //Invoke the method call
            scope.validateBlank();
            //modify your expect statement to match your logic
            expect(scope.validateBlank).toBeTrue()
        });

        it('should call scope.resetFlags ', function() {
            //Invoke the method call
            scope.resetFlags(mockData.accordian);
            //modify your expect statement to match your logic
            expect(scope.resetFlags).toBeTrue()
        });




    });


});