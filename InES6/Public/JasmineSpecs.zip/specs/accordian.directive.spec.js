define(['jQuery', 'angular', 'angular-mock'], function($) {

//Declare all global variables here
var accordian.directive, scope,
    compile,
    $compile,
    CommonDataService;

// Read mock data from external file uncomment this to read mock data from json file

// $.get('base/test/unit/claims/dental/JSON/dentalBasicClaim.json',function(data){
// 	var mockData=JSON.parse(data.toString());
// });

//Any other mock objects/ functions that is required can be intialized here
// require("generalFunctions");

//Main describe here
describe('accordian.directive', function() {

    //beforeEach function.  create and intialize module, controllers and services here
    beforeEach(function() {
        spyOn(angular, 'element').and.callFake(mockData.angularFaked);
        module(he);
        inject(function($rootScope, $compile, _$compile_, _CommonDataService_) {
            scope = $rootScope.$new();
            compile = $compile;
            accordian.directive = getCompiledElement();
            directiveElem = getCompiledElement();

            function getCompiledElement() {
                var template = angular.element('<div'
                    accordian '> </div>');
                var element = angular.element(template);
                var compiledElement = compile(element)(scope);
                scope.$digest();
                return compiledElement
            }
            $compile = _$compile_;
            CommonDataService = _CommonDataService_;
        });


    });
});

afterEach(function() {

});

//create additional describes if needed

//create your it and expect statements here
it('should instantiate accordian.directive', function() {
    expect(accordian.directive).toBeDefined();
});


it('should have replaced directive element', function() {
    var compiledDirective = compile(angular.element('<div><accordian></accordian></div>'))(scope);
    scope.$digest();

    expect(compiledDirective.find('accordian').length).toEqual(0);
});






it('should call controller', function() {
    //Invoke the method call
    accordian.directive.controller(mockData.scope, mockData.$attrs);
    //modify your expect statement to match your logic
    expect(accordian.directive.controller).toBeTrue()
});

it('should call scope.addAlertHeading ', function() {
    //Invoke the method call
    scope.addAlertHeading(mockData.accElement);
    //modify your expect statement to match your logic
    expect(scope.addAlertHeading).toBeTrue()
});

it('should call scope.addCheckHeading ', function() {
    //Invoke the method call
    scope.addCheckHeading(mockData.accElement);
    //modify your expect statement to match your logic
    expect(scope.addCheckHeading).toBeTrue()
});

it('should call scope.expandAccordian ', function() {
    //Invoke the method call
    scope.expandAccordian(mockData.accElement, mockData.accId);
    //modify your expect statement to match your logic
    expect(scope.expandAccordian).toBeTrue()
});

it('should call scope.collapseAccordian ', function() {
    //Invoke the method call
    scope.collapseAccordian(mockData.accElement, mockData.accId);
    //modify your expect statement to match your logic
    expect(scope.collapseAccordian).toBeTrue()
});

it('should call scope.removeCheckHeading ', function() {
    //Invoke the method call
    scope.removeCheckHeading(mockData.accElement);
    //modify your expect statement to match your logic
    expect(scope.removeCheckHeading).toBeTrue()
});

it('should call scope.updateChildAccordians ', function() {
    //Invoke the method call
    scope.updateChildAccordians();
    //modify your expect statement to match your logic
    expect(scope.updateChildAccordians).toBeTrue()
});

it('should call link', function() {
    //Invoke the method call
    accordian.directive.link(mockData.scope);
    //modify your expect statement to match your logic
    expect(accordian.directive.link).toBeTrue()
});




});


});